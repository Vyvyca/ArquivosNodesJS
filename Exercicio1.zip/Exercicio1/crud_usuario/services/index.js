const UsuarioService = require("./UsuarioService");

module.exports = {
  UsuarioService: UsuarioService,
};
