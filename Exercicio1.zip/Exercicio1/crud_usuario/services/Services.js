class Services {
  constructor(nomeModelo) {
    this.nomeModelo = nomeModelo;
  }
}

module.exports = Services;
