const express = require("express");
const DatabaseConnection = require("./../config/connection-db");
const Log = require("./../middlewares/log");

const router = express.Router();

const log = new Log();

router.get("/users", async (req, resp) => {
  log.log("GET","/users");
  const databaseConnection = new DatabaseConnection();
  const db = await databaseConnection.connect(); 
  const { rows } = await db.query("select * from tblusers");
  resp.send(rows);
});

router.get("/user", async (req, resp) => {
  log.log("GET","/user");
  const { body } = req;
  const { id } = body;
  const databaseConnection = new DatabaseConnection();
  const db = await databaseConnection.connect();
  const { rows } = await db.query(
    "select * from tblusers where id = ($1)",
    [id]
  );
  resp.status(201).send(rows);
});

router.post("/user", async (req, resp) => {
  log.log("POST","/user");
  const { body } = req;
  const { nome, email, password } = body;
  const databaseConnection = new DatabaseConnection();
  const db = await databaseConnection.connect();
  const { rows } = await db.query(
    "insert into tblusers (nome, email, password, createdat) values($1, $2, $3, NOW()::timestamp) RETURNING *",
    [nome, email, password]
  );
  resp.status(201).send(rows);
});

router.delete("/user", async (req, resp) => {
  log.log("DELETE","/user");
  const { body } = req;
  const { id } = body;
  const databaseConnection = new DatabaseConnection();
  const db = await databaseConnection.connect();
  const { rows } = await db.query(
    "delete from tblusers where id = ($1)",
    [id]
  );
  resp.status(201).send("success");
});

router.put("/user", async (req, resp) => {
  log.log("PUT","/user");
  const { body } = req;
  const { id, nome, email, password } = body;
  const databaseConnection = new DatabaseConnection();
  const db = await databaseConnection.connect();
  const { rows } = await db.query(
    "update tblusers set nome=($2), email=($3), password=($4), updateat=NOW()::timestamp where id = ($1) RETURNING *",
    [id, nome, email, password]
  );
  resp.status(201).send(rows);
});

module.exports = router;
